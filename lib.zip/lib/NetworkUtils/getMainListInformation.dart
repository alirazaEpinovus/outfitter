import 'package:firebase_database/firebase_database.dart';
import 'dart:async' show Future;
import 'package:outfitters/Models/homeScreenModel.dart';

class MakeCall {
  final databaseReference = FirebaseDatabase.instance.reference();

  Future<DataSnapshot> getDatabase() async {
    DataSnapshot dataSnapshot = await databaseReference.once();
    return dataSnapshot;
  }

  Future<List<CollectionsDetails>> firebaseCollectionCalls() async {
    CollectionsList collectionsList;
    DataSnapshot dataSnapshot = await databaseReference.once();
    Map<dynamic, dynamic> jsonResponse =
        dataSnapshot.value['custom_collections'];
    collectionsList = new CollectionsList.fromJSON(jsonResponse);
    return collectionsList.collectionsList;
  }

  Future<List<SubCollections>> firebaseSubCollectionCalls() async {
    CollectionsDetails collectionsDetails;
    DataSnapshot dataSnapshot = await databaseReference.once();
    Map<dynamic, dynamic> jsonResponse =
        dataSnapshot.value['custom_collections'];
    collectionsDetails = new CollectionsDetails.fromJSON(jsonResponse);
    return collectionsDetails.subCollection;
  }

  Future<List<NestedSubCollections>> firebaseNestedSubCollectionCalls() async {
    SubCollections subCollection;
    DataSnapshot dataSnapshot = await databaseReference.once();
    Map<dynamic, dynamic> jsonResponse =
        dataSnapshot.value['custom_collections'];
    subCollection = new SubCollections.fromJSON(jsonResponse);
    return subCollection.nestedSubCollection;
  }
}
