class SortingModel{
  String sortingString;
  String sortingValue;

  SortingModel({
    this.sortingString,this.sortingValue
  });
}