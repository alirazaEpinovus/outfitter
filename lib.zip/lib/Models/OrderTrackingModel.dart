class OrderTrackingModel {
  int statusCode;
  String status;

  OrderTrackingModel({this.statusCode, this.status});

  int get getStatusCode => statusCode;

  String get getstatus => status;
}
