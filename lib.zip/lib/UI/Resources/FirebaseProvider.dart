// import 'package:firebase_database/firebase_database.dart';
// import 'package:outfitters/Models/FiltersModel.dart';

// class FirebaseProvider{
//  final databaseReference = FirebaseDatabase.instance.reference();

//  Future<FiltersModel> fetchFilters() async {

//     DataSnapshot snapshot = await databaseReference
//     .once();

//     return FiltersModel.fromJson(snapshot.value);

//   }
// }
