import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:outfitters/Models/FiltersModel.dart';
import 'package:outfitters/Models/homeScreenModel.dart';
import 'package:outfitters/UI/Resources/Repository.dart';

class HomeScreenNotifier with ChangeNotifier {
  final repository = Repository();
  DataSnapshot dataSnapshot;
  Announcement ann;
  Filterx filtersModel;
  List<SliderDetails> sliders = [];
  List<CollectionsDetails> collectionDetails = [];
  List<SubCollections> subCollections = [];
  List<NestedSubCollections> nestedsub = [];

  HomeScreenNotifier() {
    getDatabase();
  }
  Announcement get sss => ann;
  Filterx get filterx => filtersModel;
  List<SliderDetails> get slidersData => sliders;
  List<CollectionsDetails> get collections => collectionDetails;
  List<SubCollections> get subCollection => subCollections;
  List<NestedSubCollections> get nestedsubColl => nestedsub;

  getDatabase() async {
    CollectionsList collectionsList;
    Sliders sliderlist;
    Announcement announcement;
    Filterx allFiltersModel;
    CollectionsDetails collectionsDetails;
    SubCollections subCollection;
    dataSnapshot = await repository.getDatabase();
    if (dataSnapshot != null) {
      Map<dynamic, dynamic> jsonResponse =
          dataSnapshot.value['custom_collections'];
      Map<dynamic, dynamic> jsonPages = dataSnapshot.value['custom_pages'];
      Map<dynamic, dynamic> jsonAnnounce = dataSnapshot.value['announcement'];
      Map<dynamic, dynamic> jsonFilters =
          dataSnapshot.value['new_filters_1']['filters'];
      announcement = new Announcement.fromJson(jsonAnnounce);
      ann = announcement;
      allFiltersModel = new Filterx.fromJson(jsonFilters);
      filtersModel = allFiltersModel;
      sliderlist = new Sliders.fromJSON(jsonPages);
      sliders = sliderlist.sliders;
      collectionsList = new CollectionsList.fromJSON(jsonResponse);
      collectionDetails = collectionsList.collectionsList;
      collectionsDetails = new CollectionsDetails.fromJSON(jsonResponse);
      subCollections = collectionsDetails.subCollection;
      subCollection = new SubCollections.fromJSON(jsonResponse);
      nestedsub = subCollection.nestedSubCollection;
      notifyListeners();
    }
  }
}
